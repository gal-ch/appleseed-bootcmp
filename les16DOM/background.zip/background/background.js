
let bac1=()=>
{
    document.querySelector('#myBac').style.backgroundImage = "url('https://cdn.pixabay.com/photo/2017/08/30/01/05/milky-way-2695569_960_720.jpg')";
}
let bac2=()=>
{
    document.querySelector('#myBac').style.backgroundImage = "url('https://ak6.picdn.net/shutterstock/videos/1027713866/thumb/10.jpg')";
}
let bac3=()=>
{
    document.querySelector('#myBac').style.backgroundImage = "url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTQbs-Mo2ris45e7qOMJ0D1h4NxKrKb6HMNPaJbZfhzalmaZWbm&s')";
}

btn1.addEventListener('click', bac1);
btn2.addEventListener('click', bac2);
btn3.addEventListener('click', bac3);
